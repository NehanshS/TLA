import { randomUUID } from 'node:crypto'
crypto.randomUUID = randomUUID
