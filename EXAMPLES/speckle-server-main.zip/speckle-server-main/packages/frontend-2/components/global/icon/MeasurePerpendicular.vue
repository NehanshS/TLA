<template>
  <svg
    width="36"
    height="36"
    viewBox="0 0 36 36"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M1.5 23.9655V3.00003L10.5 10.8621V31.5L1.5 23.9655Z"
      stroke="#CBD5E1"
      stroke-linejoin="round"
    />
    <path
      d="M1.5 3.00003L22.5 1.50003"
      stroke="#CBD5E1"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M1.5 24L22.5 22.5"
      stroke="#CBD5E1"
      stroke-linecap="round"
      stroke-linejoin="round"
      stroke-dasharray="2 2"
    />
    <path
      d="M10.5 31.5L31.5 30"
      stroke="#CBD5E1"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M10.5 11.25L31.5 9.75003"
      stroke="#CBD5E1"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M22.5 1.50003L31.5 9.34814V30"
      stroke="#CBD5E1"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M22.5 1.50003V22.5"
      stroke="#CBD5E1"
      stroke-linecap="round"
      stroke-linejoin="round"
      stroke-dasharray="2 2"
    />
    <path
      d="M22.5 22.5L31.5 30"
      stroke="#CBD5E1"
      stroke-linecap="round"
      stroke-linejoin="round"
      stroke-dasharray="2 2"
    />
    <path
      d="M6.04926 17.378L27.0493 15.878"
      stroke="#3B82F6"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M4.37823 19.3902L7.10927 15.3896"
      stroke="#3B82F6"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M25.6345 17.8902L28.3656 13.8896"
      stroke="#3B82F6"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M4.96887 14.093L7.03114 20.663"
      stroke="#3B82F6"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M26.2251 12.593L28.2874 19.163"
      stroke="#3B82F6"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
