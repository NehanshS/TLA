<template>
  <svg
    width="194"
    height="141"
    viewBox="0 0 194 141"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <rect
      x="0.585984"
      y="0.177422"
      width="136.5"
      height="102.75"
      rx="5.625"
      transform="matrix(0.948683 -0.316228 0.613941 0.789352 -0.0788556 58.8926)"
      stroke="currentColor"
      class="stroke-outline-5 fill-foundation-2"
      stroke-width="1"
    />
    <g clip-path="url(#clip0_3199_61388)">
      <g clip-path="url(#clip1_3199_61388)">
        <path
          d="M90.747 90.6301L83.1931 93.148C81.1897 93.8158 78.7533 93.7941 76.4199 93.0876C74.0865 92.3811 72.0472 91.0477 70.7507 89.3808L57.7147 72.6202C56.4182 70.9532 55.9706 69.0893 56.4705 67.4384C56.9703 65.7874 58.3766 64.4848 60.3801 63.817L90.5956 53.7451C92.5991 53.0773 95.0355 53.0991 97.3689 53.8056C99.7023 54.5121 101.742 55.8454 103.038 57.5124L116.074 74.273C117.371 75.9399 117.818 77.8039 117.318 79.4548C116.818 81.1057 115.412 82.4084 113.409 83.0762L105.855 85.5941L103.189 94.3973L90.747 90.6301Z"
          fill="currentColor"
          class="stroke-outline-5 fill-foundation-page"
          stroke="currentColor"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
        <path
          d="M73.9053 72.7725L91.0969 67.0419"
          stroke="currentColor"
          class="stroke-outline-5"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
        <path
          d="M80.0811 80.9941L95.1888 75.9582"
          stroke="currentColor"
          class="stroke-outline-5"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </g>
      <g clip-path="url(#clip2_3199_61388)">
        <path
          d="M110.958 60.9562L104.483 63.1145C102.766 63.6869 100.677 63.6682 98.6773 63.0627C96.6772 62.4571 94.9293 61.3142 93.818 59.8854L82.6442 45.5192C81.533 44.0904 81.1493 42.4927 81.5778 41.0776C82.0062 39.6625 83.2117 38.546 84.9289 37.9736L110.828 29.3406C112.545 28.7682 114.633 28.7868 116.634 29.3924C118.634 29.9979 120.382 31.1408 121.493 32.5696L132.667 46.9358C133.778 48.3647 134.161 49.9623 133.733 51.3774C133.305 52.7925 132.099 53.909 130.382 54.4814L123.907 56.6397L121.623 64.1853L110.958 60.9562Z"
          stroke="currentColor"
          class="stroke-outline-5 fill-foundation"
          fill="currentColor"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
        <path
          d="M96.2295 45.5137L113.496 39.7583"
          stroke="currentColor"
          class="stroke-outline-5"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
        <path
          d="M101.816 52.6968L114.766 48.3803"
          stroke="currentColor"
          class="stroke-outline-5"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </g>
    </g>
    <rect
      x="0.585984"
      y="0.177422"
      width="136.5"
      height="102.75"
      rx="5.625"
      transform="matrix(0.948683 -0.316228 0.613941 0.789352 -0.0788556 43.8926)"
      stroke="currentColor"
      class="dash-moving stroke-outline-5"
      stroke-dashoffset="25"
      stroke-width="1"
      stroke-dasharray="3 4"
    />
    <defs>
      <clipPath id="clip0_3199_61388">
        <rect
          width="137.25"
          height="103.5"
          rx="6"
          transform="matrix(0.948683 -0.316228 0.613941 0.789352 0 43.6699)"
          fill="currentColor"
          class="fill-foundation"
        />
      </clipPath>
      <clipPath id="clip1_3199_61388">
        <rect
          width="63.7"
          height="63.7"
          fill="currentColor"
          class="fill-foundation"
          transform="matrix(0.948683 -0.316228 0.613941 0.789352 38.7539 60.4727)"
        />
      </clipPath>
      <clipPath id="clip2_3199_61388">
        <rect
          width="54.6"
          height="54.6"
          fill="currentColor"
          class="fill-foundation"
          transform="matrix(0.948683 -0.316228 0.613941 0.789352 66.3926 35.1069)"
        />
      </clipPath>
    </defs>
  </svg>
</template>
<style scoped>
.dash-moving {
  animation: dash 2s ease-in-out 0s 1 normal forwards running;
}

@keyframes dash {
  100% {
    stroke-dashoffset: 0;
  }
}
</style>
