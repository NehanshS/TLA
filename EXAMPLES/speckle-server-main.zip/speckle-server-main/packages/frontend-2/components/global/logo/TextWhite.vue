<template>
  <NuxtLink to="/">
    <img
      src="~/assets/images/speckle_text_logo_white.svg"
      alt="Speckle logo"
      width="192"
    />
  </NuxtLink>
</template>
