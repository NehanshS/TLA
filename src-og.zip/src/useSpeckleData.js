import { useEffect, useState } from "react";

const SPECKLE_API = "https://app.speckle.systems/api/v1";
const PROJECT_ID = process.env.REACT_APP_SPECKLE_PROJECT_ID;
const MODEL_ID = process.env.REACT_APP_SPECKLE_MODEL_ID;
const TOKEN = process.env.REACT_APP_SPECKLE_TOKEN;

// List the custom params you want to extract
const METRICS = [
  "EUI",
  "Circulation",
  "ClearancesMet",
  "EquipmentCount",
  "MaterialCost",
  "EquipmentCost",
  "LayoutScore",
  "EUIScore",
  "EstimatedWorkers"
];

// Helper to recursively extract all numeric values by name
function recursiveExtract(obj, keys, result = {}) {
  if (!obj) return result;

  // Extract from parameters if present
  if (obj.parameters) {
    keys.forEach((key) => {
      if (
        obj.parameters[key] &&
        (typeof obj.parameters[key].value === "number" ||
          !isNaN(parseFloat(obj.parameters[key].value)))
      ) {
        result[key] = parseFloat(obj.parameters[key].value);
      }
    });
  }

  // Some objects use direct properties (not "parameters")
  keys.forEach((key) => {
    if (
      obj[key] &&
      (typeof obj[key] === "number" || !isNaN(parseFloat(obj[key])))
    ) {
      result[key] = parseFloat(obj[key]);
    }
  });

  // Traverse children/arrays recursively
  if (Array.isArray(obj.elements)) {
    obj.elements.forEach((child) => recursiveExtract(child, keys, result));
  }
  if (Array.isArray(obj.children)) {
    obj.children.forEach((child) => recursiveExtract(child, keys, result));
  }

  return result;
}

export default function useSpeckleData() {
  const [data, setData] = useState({
    loading: true,
    error: null,
    projectName: "",
    updatedAt: "",
    ...Object.fromEntries(METRICS.map((k) => [k, null]))
  });

  useEffect(() => {
    let cancelled = false;
    async function fetchData() {
      try {
        // Get latest model info (contains projectName, updatedAt, etc)
        const modelRes = await fetch(
          `${SPECKLE_API}/projects/${PROJECT_ID}/models/${MODEL_ID}`,
          {
            headers: { Authorization: `Bearer ${TOKEN}` }
          }
        );
        if (!modelRes.ok) throw new Error("Failed to fetch model");
        const model = await modelRes.json();

        const projectName = model.model.name;
        const updatedAt = model.model.versions?.[0]?.createdAt || "";

        // Get latest version ID
        const latestVersionId = model.model.versions?.[0]?.id;
        if (!latestVersionId) throw new Error("No versions found for model");

        // Get root object for latest version
        const objRes = await fetch(
          `${SPECKLE_API}/projects/${PROJECT_ID}/models/${MODEL_ID}/versions/${latestVersionId}/object`,
          {
            headers: { Authorization: `Bearer ${TOKEN}` }
          }
        );
        if (!objRes.ok) throw new Error("Failed to fetch object");
        const { object } = await objRes.json();

        // Extract metrics
        const metrics = recursiveExtract(object, METRICS);

        if (!cancelled)
          setData({
            loading: false,
            error: null,
            projectName,
            updatedAt,
            ...Object.fromEntries(
              METRICS.map((k) => [k, metrics[k] ?? null])
            )
          });
      } catch (error) {
        if (!cancelled)
          setData((prev) => ({
            ...prev,
            loading: false,
            error: error.message || "Failed to load data"
          }));
      }
    }

    fetchData();
    return () => {
      cancelled = true;
    };
  }, []);

  return data;
}
