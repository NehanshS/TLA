// components/ViewportGrid.jsx
export default function ViewportGrid() {
  return <div className="model-viewport-grid" />;
}
