<template>
  <svg
    width="36"
    height="36"
    viewBox="0 0 36 36"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M3 25.4655V4.50003L12 12.3621V33L3 25.4655Z"
      stroke="#CBD5E1"
      stroke-linejoin="round"
    />
    <path
      d="M3 4.50003L24 3.00003"
      stroke="#CBD5E1"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M3 25.5L24 24"
      stroke="#CBD5E1"
      stroke-linecap="round"
      stroke-linejoin="round"
      stroke-dasharray="2 2"
    />
    <path
      d="M12 33L33 31.5"
      stroke="#CBD5E1"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M12 12.75L33 11.25"
      stroke="#CBD5E1"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M24 3.00003L33 10.8481V31.5"
      stroke="#CBD5E1"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M24 3.00003V24"
      stroke="#CBD5E1"
      stroke-linecap="round"
      stroke-linejoin="round"
      stroke-dasharray="2 2"
    />
    <path
      d="M24 24L33 31.5"
      stroke="#CBD5E1"
      stroke-linecap="round"
      stroke-linejoin="round"
      stroke-dasharray="2 2"
    />
    <path
      d="M3 25.5L33 10.5"
      stroke="#3B82F6"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <circle cx="3" cy="25.5" r="2.25" fill="#3B82F6" />
    <circle cx="33" cy="10.5" r="2.25" fill="#3B82F6" />
  </svg>
</template>
