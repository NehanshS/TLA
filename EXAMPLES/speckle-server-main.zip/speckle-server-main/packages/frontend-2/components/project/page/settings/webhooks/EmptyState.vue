<template>
  <ProjectEmptyState title="No webhooks, yet." />
</template>
