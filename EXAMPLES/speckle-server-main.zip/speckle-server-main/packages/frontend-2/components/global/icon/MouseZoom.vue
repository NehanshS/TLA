<template>
  <svg
    width="25"
    height="24"
    viewBox="0 0 25 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M19.5 11.5C19.5 17.299 18 22 13 22C8 22 6.5 17.299 6.5 11.5C6.5 5.70101 6.5 1 13 1C19.5 1 19.5 5.70101 19.5 11.5Z"
      stroke="currentColor"
    />
    <path d="M6.5 9H19.5" stroke="#94A3B8" />
    <rect
      x="11.5"
      y="2.5"
      width="3"
      height="5"
      rx="1"
      stroke="#334155"
      stroke-linejoin="round"
    />
  </svg>
</template>
