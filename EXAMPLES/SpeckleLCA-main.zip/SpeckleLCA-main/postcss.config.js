/* eslint-disable no-undef */
module.exports = {
	plugins: {
		tailwindcss: {},
		autoprefixer: {}
	}
}
