import useMockData from "./useMockData";
import HeaderRow from "./components/HeaderRow";
import ViewportGrid from "./components/ViewportGrid";
import ViewportOverlay from "./components/ViewportOverlay";
import SpeckleViewer from "./components/SpeckleViewer";
import FloatingSwitchers from "./components/FloatingSwitchers";
import CostPanel from "./components/CostPanel";
import VerticalMetrics from "./components/VerticalMetrics";

export default function App() {
  const {
    header, cost, metrics,
    mode, zone, modes, zones,
    setProjectName, nextMode, prevMode, nextZone, prevZone
  } = useMockData();

  return (
    <div className="relative bg-black text-white w-screen h-screen overflow-hidden" style={{fontFamily: "'Roboto', 'system-ui', sans-serif"}}>
      {/* Full grid and viewer base layer */}
      <ViewportGrid />

      {/* Speckle 3D Viewer, overlays grid */}
      <div className="absolute inset-0 z-10">
        <SpeckleViewer streamId="YOUR_STREAM_ID" /* commitId="YOUR_COMMIT_ID" branch="main" */ />
      </div>

      {/* Optional: gradient overlay on top of viewer */}
      <ViewportOverlay />

      {/* UI panels/overlays (z-20 or above) */}
      <HeaderRow
        projectName={header.projectName}
        facilityScore={header.facilityScore}
        lastSynced={header.lastSynced}
        setProjectName={setProjectName}
      />
      <FloatingSwitchers
        mode={mode}
        zone={zone}
        nextMode={nextMode}
        prevMode={prevMode}
        nextZone={nextZone}
        prevZone={prevZone}
      />
      <CostPanel {...cost} />
      <VerticalMetrics metrics={metrics} />
    </div>
  );
}
