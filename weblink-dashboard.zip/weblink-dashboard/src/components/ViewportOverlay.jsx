export default function ViewportOverlay() {
  return <div className="viewport-overlay-dark"></div>;
}