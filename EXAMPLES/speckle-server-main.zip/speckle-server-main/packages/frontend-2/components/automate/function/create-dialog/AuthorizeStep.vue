<template>
  <div class="text-foreground text-normal">
    You need to authorize access to the Speckle Automate GitHub app first. This will
    enable us to automatically set up your function and its associated resources
    (repositories e.g.).
  </div>
</template>
