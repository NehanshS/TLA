export default function ViewportGrid() {
  return <div className="model-viewport-grid"></div>;
}