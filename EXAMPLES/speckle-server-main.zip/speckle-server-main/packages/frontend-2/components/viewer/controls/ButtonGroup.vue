<template>
  <div
    class="bg-foundation text-foreground rounded-lg w-8 md:w-10 flex flex-col justify-center items-center md:gap-1 border border-outline-2 shadow"
  >
    <slot></slot>
  </div>
</template>
<script setup lang="ts"></script>
