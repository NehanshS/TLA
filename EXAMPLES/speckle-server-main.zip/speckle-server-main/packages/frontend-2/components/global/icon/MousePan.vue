<template>
  <svg
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M19 11.5C19 17.299 17.5 22 12.5 22C7.5 22 6 17.299 6 11.5C6 5.70101 6 1 12.5 1C19 1 19 5.70101 19 11.5Z"
      stroke="#94A3B8"
    />
    <path d="M6 9H19" stroke="#94A3B8" />
    <path d="M19 9C19 6.5 19 1 12.5 1" stroke="#334155" />
    <path d="M19.5 9H12" stroke="#334155" />
    <path d="M12.5 0.5V9.5" stroke="#334155" />
  </svg>
</template>
