<template>
  <svg
    width="16"
    height="16"
    viewBox="0 0 16 16"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M5 15V1H6.5V15H5Z"
      fill="currentColor"
    />
    <path
      d="M10.9002 8.28183C11.0333 8.1154 11.0333 7.8846 10.9002 7.71817L8.87389 5.18369C8.59132 4.83026 8 5.02096 8 5.46552V10.5345C8 10.979 8.59132 11.1697 8.87389 10.8163L10.9002 8.28183Z"
      fill="currentColor"
    />
    <rect
      x="0.75"
      y="0.75"
      width="14.5"
      height="14.5"
      rx="3.25"
      stroke="currentColor"
      stroke-width="1.5"
    />
  </svg>
</template>
