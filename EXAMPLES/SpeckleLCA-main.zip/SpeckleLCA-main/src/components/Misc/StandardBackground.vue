<template>
	<div
		class="fixed inset-0 w-full h-full pattern-dots pattern-black pattern-bg-transparent pattern-size-4 -z-20"
		:style="{
			'--pattern-opacity': '0.2'
		}"
	></div>
</template>

<script setup lang="ts"></script>
