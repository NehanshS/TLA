<template>
  <svg
    width="16"
    height="16"
    viewBox="0 0 16 16"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M11 15V1H9.5V15H11Z"
      fill="currentColor"
    />
    <path
      d="M5.0998 8.28183C4.96673 8.1154 4.96673 7.8846 5.0998 7.71817L7.12611 5.18369C7.40868 4.83026 8 5.02096 8 5.46552L8 10.5345C8 10.979 7.40868 11.1697 7.12611 10.8163L5.0998 8.28183Z"
      fill="currentColor"
    />
    <rect
      x="-0.75"
      y="0.75"
      width="14.5"
      height="14.5"
      rx="3.25"
      transform="matrix(-1 0 0 1 14.5 0)"
      stroke="currentColor"
      stroke-width="1.5"
    />
  </svg>
</template>
